from setuptools import setup

version='0.6'
setup()